Feature: Facebook Login

  Scenario: Login with valid credentials
    Given User opens the login page
    When user enters the username "testuser@example.com"
    And user enters the password "testpassword"
    Then click the Login Button
